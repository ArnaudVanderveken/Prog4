#pragma once
#include <glm/glm.hpp>

namespace dae
{
	struct Transform final
	{
		glm::vec3 position{};
	};
}
